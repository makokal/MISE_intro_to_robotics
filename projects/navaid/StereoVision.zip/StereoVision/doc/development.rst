StereoVision source documentation
=================================

.. automodule:: stereovision

